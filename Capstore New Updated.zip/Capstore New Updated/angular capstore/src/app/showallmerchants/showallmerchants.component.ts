import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service'

@Component({
  selector: 'app-showallmerchants',
  templateUrl: './showallmerchants.component.html',
  styleUrls: ['./showallmerchants.component.css']
})
export class ShowallmerchantsComponent implements OnInit {
  result: any
  submitted = false;
  constructor(private service: LoginService) { }

  ngOnInit() {
    this.getMerchants()
  }
  getMerchants(): void {
    this.service.viewmerchants().subscribe(data => {
      this.result = data;
      this.submitted = true;
      console.log(this.result);
    });
  }

  delete(merchantId) {
    console.log(merchantId)
    this.service.deleteMerchant(merchantId).subscribe(data => {
      this.result = data;
      alert(this.result)
      window.location.reload();
    });
  }

  searchByName(event) {
    this.result = this.result.filter(singleItem =>
      singleItem.merchantName.toLowerCase().includes(event.target.value.toLowerCase())
    )
  }
  searchByMerchantType(event) {
    this.result = this.result.filter(singleItem =>
      singleItem.merchantType.toLowerCase().includes(event.target.value.toLowerCase())
    )
  }
  searchByPhone(event) {
    this.result = this.result.filter(singleItem =>
      singleItem.phoneNo.toLowerCase().includes(event.target.value.toLowerCase())
    )
  }
  searchByEmail(event) {
    this.result = this.result.filter(singleItem =>
      singleItem.email.toLowerCase().includes(event.target.value.toLowerCase())
    )
  }
}
