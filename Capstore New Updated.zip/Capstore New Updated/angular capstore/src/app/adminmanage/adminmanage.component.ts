import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminmanage',
  templateUrl: './adminmanage.component.html',
  styleUrls: ['./adminmanage.component.css']
})

export class AdminmanageComponent implements OnInit {
  
  constructor() { }
  login=false;
 
  ngOnInit() {
    
    sessionStorage.setItem("lastname", "Smith");

    sessionStorage.setItem("first", "KARL");
   
    console.log(sessionStorage.getItem("first"))
    console.log(sessionStorage.getItem("lastname"))
    sessionStorage.clear()
    if(sessionStorage.getItem("lastname")==null)
    {
      
    }
  }
  
}
